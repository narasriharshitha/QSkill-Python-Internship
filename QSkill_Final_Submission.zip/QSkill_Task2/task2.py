import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import LabelEncoder
import numpy as np

# Load dataset
df = pd.read_csv('housing.csv')

print("=" * 50)
print("HOUSE PRICE PREDICTION")
print("Linear Regression Model")
print("=" * 50)

print("\nFirst 5 rows:")
print(df.head())

print(f"\nDataset size: {df.shape[0]} houses, {df.shape[1]} features")

# Convert text columns to numbers
le = LabelEncoder()
df['location'] = le.fit_transform(df['location'])

# Features and target
X = df.drop(columns=['price'])
y = df['price']

print(f"\nFeatures: {list(X.columns)}")
print(f"Target: price")

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
print(f"\nTraining samples: {len(X_train)}")
print(f"Testing samples:  {len(X_test)}")

# Train model
model = LinearRegression()
model.fit(X_train, y_train)
print("\nModel trained successfully!")

# Evaluate
y_pred = model.predict(X_test)
r2 = r2_score(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)

print("\n" + "=" * 50)
print("MODEL RESULTS")
print("=" * 50)
print(f"R² Score:  {r2:.4f}  (closer to 1.0 = better)")
print(f"RMSE:      ${rmse:,.2f}")

# Feature importance
print("\n" + "=" * 50)
print("FEATURE IMPORTANCE")
print("=" * 50)
for feat, coef in zip(X.columns, model.coef_):
    print(f"  {feat:10s}: {coef:,.2f}")

# Plot actual vs predicted
plt.figure(figsize=(8, 5))
plt.scatter(y_test, y_pred, alpha=0.7, color='steelblue', edgecolors='white', s=80)
plt.plot([y_test.min(), y_test.max()],
         [y_test.min(), y_test.max()], 'r--', lw=2, label='Perfect prediction')
plt.xlabel('Actual Price ($)')
plt.ylabel('Predicted Price ($)')
plt.title('Actual vs Predicted House Prices', fontsize=14, fontweight='bold')
plt.legend()
plt.tight_layout()
plt.savefig('regression_plot.png', dpi=150)
plt.show()
print("\nChart saved as regression_plot.png!")

# Sample predictions
print("\n" + "=" * 50)
print("SAMPLE PREDICTIONS")
print("=" * 50)
for i in range(3):
    actual = y_test.iloc[i]
    predicted = y_pred[i]
    print(f"  House {i+1}: Actual=${actual:,}  Predicted=${predicted:,.0f}")

print("\nTASK 2 COMPLETE!")
