import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv('exams.csv')

print("=" * 50)
print("FIRST 5 ROWS OF THE DATASET")
print("=" * 50)
print(df.head())

print("\n" + "=" * 50)
print("AVERAGE SCORES")
print("=" * 50)
print(f"Average Math Score:    {df['math score'].mean():.2f}")
print(f"Average Reading Score: {df['reading score'].mean():.2f}")
print(f"Average Writing Score: {df['writing score'].mean():.2f}")

plt.figure(figsize=(8, 5))
avg_scores = df[['math score', 'reading score', 'writing score']].mean()
avg_scores.plot(kind='bar', color=['steelblue', 'coral', 'mediumseagreen'], edgecolor='white')
plt.title('Average Score by Subject', fontsize=14, fontweight='bold')
plt.xlabel('Subject')
plt.ylabel('Average Score')
plt.xticks(rotation=0)
plt.ylim(0, 100)
for i, v in enumerate(avg_scores):
    plt.text(i, v + 1, f'{v:.1f}', ha='center', fontsize=11)
plt.tight_layout()
plt.savefig('bar_chart.png', dpi=150)
plt.show()
print("Bar chart saved!")

plt.figure(figsize=(8, 5))
plt.scatter(df['math score'], df['reading score'], alpha=0.5, color='steelblue', edgecolors='white', s=60)
plt.title('Math Score vs Reading Score', fontsize=14, fontweight='bold')
plt.xlabel('Math Score')
plt.ylabel('Reading Score')
plt.tight_layout()
plt.savefig('scatter_plot.png', dpi=150)
plt.show()
print("Scatter plot saved!")

plt.figure(figsize=(7, 5))
numeric_df = df[['math score', 'reading score', 'writing score']]
sns.heatmap(numeric_df.corr(), annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5, square=True)
plt.title('Correlation Heatmap of Scores', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('heatmap.png', dpi=150)
plt.show()
print("Heatmap saved!")

print("\nALL DONE! Check your QSkill_Task1 folder for the 3 chart images!")
